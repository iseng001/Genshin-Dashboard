package com.risandi.gdashboard

import android.net.Uri
import android.os.Handler
import android.os.Looper
import android.webkit.CookieManager
import android.webkit.WebChromeClient
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.FolderOpen
import androidx.compose.material.icons.filled.Link
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView

@Composable
fun DashboardScreen() {
    var url by remember { mutableStateOf("https://act.hoyolab.com/app/community-game-records/index.html?game_id=2") }
    var live by remember { mutableStateOf(false) }
    var intervalSec by remember { mutableStateOf(30) }
    val snackbar = remember { SnackbarHostState() }

    val ctx = LocalContext.current
    val pickCookie = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { uri: Uri? ->
        if (uri != null) {
            val txt = FileUtils.readTextFromUri(ctx, uri)
            val parsed = CookieUtils.parseCookieText(txt)
            if (!parsed.cookies.containsKey("ltuid") || !parsed.cookies.containsKey("ltoken")) {
                LaunchedEffect(Unit) { snackbar.showSnackbar("Cookies kurang kunci utama (ltuid/ltoken). Coba lagi.") }
            }
            CookieUtils.applyCookiesToWebView(parsed.cookies)
            LaunchedEffect(Unit) { snackbar.showSnackbar("Cookies terpasang. Memuat halaman…") }
        }
    }

    var webView: WebView? by remember { mutableStateOf(null) }

    DisposableEffect(live, intervalSec) {
        val h = Handler(Looper.getMainLooper())
        val r = object : Runnable {
            override fun run() {
                if (live) webView?.reload()
                h.postDelayed(this, (intervalSec * 1000).toLong())
            }
        }
        if (live) h.post(r)
        onDispose { h.removeCallbacksAndMessages(null) }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Genshin Dashboard") },
                actions = {
                    IconButton(onClick = { pickCookie.launch(arrayOf("*/*")) }) {
                        Icon(Icons.Default.FolderOpen, contentDescription = "Import Cookies")
                    }
                    var openMenu by remember { mutableStateOf(false) }
                    IconButton(onClick = { openMenu = true }) {
                        Icon(Icons.Default.Link, contentDescription = "Links")
                    }
                    DropdownMenu(expanded = openMenu, onDismissRequest = { openMenu = false }) {
                        DropdownMenuItem(text = { Text("Overview") }, onClick = {
                            url = "https://act.hoyolab.com/app/community-game-records/index.html?game_id=2"; openMenu = false
                        })
                        DropdownMenuItem(text = { Text("Traveler’s Diary") }, onClick = {
                            url = "https://act.hoyolab.com/ys/event/e20200928ysjournal/index.html"; openMenu = false
                        })
                        DropdownMenuItem(text = { Text("Spiral Abyss") }, onClick = {
                            url = "https://act.hoyolab.com/app/community-game-records/index.html?game_id=2#/spiral-abyss"; openMenu = false
                        })
                        DropdownMenuItem(text = { Text("Imaginarium Theater") }, onClick = {
                            url = "https://act.hoyolab.com/app/community-game-records/index.html?game_id=2#/imaginarium-theater"; openMenu = false
                        })
                    }
                }
            )
        },
        bottomBar = {
            BottomAppBar(actions = {
                var showLive by remember { mutableStateOf(live) }
                Switch(checked = showLive, onCheckedChange = {
                    showLive = it; live = it
                })
                Text(if (live) " Live" else " Live OFF")
                Spacer(Modifier.width(12.dp))
                TextButton(onClick = {
                    intervalSec = when {
                        intervalSec <= 15 -> 30
                        intervalSec <= 30 -> 45
                        else -> 15
                    }
                }) { Text("Interval: ${'$'}{intervalSec}s") }

                Spacer(Modifier.weight(1f))
                val createDoc = rememberLauncherForActivityResult(ActivityResultContracts.CreateDocument("text/html")) { uri ->
                    if (uri != null) {
                        val js = "(function(){return document.documentElement.outerHTML;})();"
                        webView?.evaluateJavascript(js) { html ->
                            val body = html.trim().trim('"').replace("\u003C", "<").replace("\n", "
").replace("\"", """)
                            ctx.contentResolver.openOutputStream(uri)?.use { out -> out.write(body.toByteArray()) }
                        }
                    }
                }
                TextButton(onClick = { createDoc.launch("genshin_report.html") }) { Text("Export HTML") }
                TextButton(onClick = { webView?.reload() }) { Text("Reload") }
            })
        },
        snackbarHost = { SnackbarHost(snackbar) }
    ) { pad ->
        AndroidView(
            modifier = Modifier.fillMaxSize().padding(pad),
            factory = { context ->
                WebView(context).apply {
                    webChromeClient = WebChromeClient()
                    webViewClient = object : WebViewClient() {
                        override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                            return false
                        }
                    }
                    settings.javaScriptEnabled = true
                    settings.domStorageEnabled = true
                    settings.userAgentString = settings.userAgentString + " GDash/1.0"
                    CookieManager.getInstance().setAcceptCookie(true)
                    loadUrl(url)
                    webView = this
                }
            },
            update = { it.loadUrl(url) }
        )
    }
}
