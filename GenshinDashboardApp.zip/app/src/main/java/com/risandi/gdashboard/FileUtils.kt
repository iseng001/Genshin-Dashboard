package com.risandi.gdashboard

import android.content.ContentResolver
import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import java.io.BufferedReader
import java.io.InputStreamReader

object FileUtils {
    fun readTextFromUri(ctx: Context, uri: Uri): String {
        ctx.contentResolver.openInputStream(uri).use { ins ->
            val br = BufferedReader(InputStreamReader(ins!!))
            return br.readText()
        }
    }

    fun getDisplayName(resolver: ContentResolver, uri: Uri): String {
        resolver.query(uri, null, null, null, null)?.use { c ->
            val idx = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
            if (c.moveToFirst() && idx >= 0) {
                return c.getString(idx) ?: "file"
            }
        }
        return "file"
    }
}
