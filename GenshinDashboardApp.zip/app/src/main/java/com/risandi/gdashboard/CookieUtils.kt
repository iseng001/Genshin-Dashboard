package com.risandi.gdashboard

import android.webkit.CookieManager

object CookieUtils {
    data class ParseResult(
        val cookies: Map<String, String>,
        val meta: Map<String, String>
    )

    fun parseCookieText(text: String): ParseResult {
        val meta = mutableMapOf<String, String>()
        val ck = mutableMapOf<String, String>()
        val trimmed = text.trim()

        // naive JSON parse (simple map or {"cookies":"..."})
        if (trimmed.startsWith("{") && trimmed.endsWith("}")) {
            try {
                val entries = trimmed.trim('{','}').split(",")
                val map = mutableMapOf<String, String>()
                for (e in entries) {
                    val p = e.split(":", limit=2)
                    if (p.size == 2) {
                        val k = p[0].trim().trim('"')
                        val v = p[1].trim().trim('"')
                        map[k] = v
                    }
                }
                val raw = map["cookies"]
                if (!raw.isNullOrBlank()) {
                    val parsed = parseCookieText(raw)
                    val mm = mutableMapOf<String,String>()
                    listOf("uid","nickname","hoyolab_level").forEach { key ->
                        map[key]?.let { mm[key] = it }
                    }
                    return ParseResult(parsed.cookies, mm)
                } else {
                    map.forEach { (k,v) ->
                        when (k.lowercase()) {
                            "uid","nickname","hoyolab_level" -> meta[k.lowercase()] = v
                            else -> ck[k.lowercase()] = v
                        }
                    }
                    return ParseResult(ck, meta)
                }
            } catch (_: Exception) { /* fallthrough */ }
        }

        // k=v; k2=v2; or per-line
        val tokens = trimmed.split(";", "
")
        for (raw in tokens) {
            val t = raw.trim()
            if (!t.contains("=")) continue
            val idx = t.indexOf("=")
            if (idx <= 0) continue
            val key = t.substring(0, idx).trim()
            val value = t.substring(idx+1).trim()
            val kl = key.lowercase()
            when (kl) {
                "uid","nickname","hoyolab_level","level" -> {
                    val mkey = if (kl=="level") "hoyolab_level" else kl
                    meta[mkey] = value
                }
                else -> ck[kl] = value
            }
        }
        if ("ltuid_v2" in ck && "ltuid" !in ck) ck["ltuid"] = ck["ltuid_v2"]!!
        if ("ltoken_v2" in ck && "ltoken" !in ck) ck["ltoken"] = ck["ltoken_v2"]!!
        return ParseResult(ck, meta)
    }

    fun applyCookiesToWebView(cookies: Map<String, String>) {
        val cm = CookieManager.getInstance()
        cm.setAcceptCookie(true)
        val domains = listOf(
            ".hoyolab.com",
            "www.hoyolab.com",
            "bbs-api-os.hoyolab.com",
            "act.hoyolab.com",
            "api-account-os.hoyoverse.com",
            ".mihoyo.com"
        )
        val keys = listOf("ltuid","ltoken","ltuid_v2","ltoken_v2","cookie_token","account_id")
        for (d in domains) {
            for (k in keys) {
                val v = cookies[k] ?: continue
                cm.setCookie("https://$d", "$k=$v; Domain=$d; Path=/; Secure; HttpOnly")
            }
        }
        cm.flush()
    }
}
